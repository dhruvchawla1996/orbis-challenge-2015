from PythonClientAPI.libs.Game.Enums import *
from PythonClientAPI.libs.Game.MapOutOfBoundsException import *


class PlayerAI:
    def __init__( self ):
        # Initialize any objects or variables you need here.
        pass

    def get_move( self, gameboard, player, opponent ):
        if player.x < opponent.x:
        	if player.direction == Direction.RIGHT:
        		return Move.FORWARD
        	else:
        		return Move.FACE_RIGHT
        elif player.x > opponent.x:
        	if player.direction == Direction.LEFT:
        		return Move.FORWARD
        	else:
        		return Move.FACE_LEFT
        else:
        	if player.y > opponent.y:
        		if player.direction == Direction.UP:
        			return Move.SHOOT
        		else:
        			return Move.FACE_UP
        	else:
        		if player.direction == Direction.DOWN:
        			return Move.SHOOT
        		else:
        			return Move.FACE_DOWN
    